from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, "signup.html")
    
    def post(self, request):
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')

            #validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
            }

        customer = Customer(first_name=first_name, last_name=last_name, phone=phone, email=email, password=password)

        error_message = None
        
        if  len(phone)<10:
            error_message = 'Phone number must be atmost 10 char long'

        elif '@' not in email:
            error_message = 'Invalid Email'

        elif  len(email)<11:
            error_message = 'email must be atleast 11 char long'

        elif customer.isExist():
            error_message = 'Email already exist'

        elif  len(password)<8:
            error_message = 'Password must be atleast 8 char long'


            # Saving data
        if not error_message:
            customer.password = make_password(customer.password)
            customer.save()
            return redirect("home")
                # return render(request, "signup.html")

        else:
            data = {
                'error': error_message,
                'values': value
                }
            return render(request, "signup.html", data)
